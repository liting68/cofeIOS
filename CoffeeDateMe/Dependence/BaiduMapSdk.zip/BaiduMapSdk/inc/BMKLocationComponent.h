//
//  BMKLocationComponent.h
//  LocationComponent
//
//  Created by Baidu on 3/31/14.
//  Copyright (c) 2014 baidu. All rights reserved.
//

#import"BMKLocationService.h"
